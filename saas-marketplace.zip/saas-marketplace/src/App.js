import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import AlbumPage from './pages/AlbumPage';
import PhotographerPage from "./pages/PhotographerPage";
import SearchPage from "./pages/SearchPage";
import PurchasedPhotosPage from "./pages/PurchasedPhotosPage";
import CartPage from "./pages/CartPage";
import ProfilePage from "./pages/ProfilePage";

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/home" element={<HomePage />} />
                 <Route path="/login" element={<LoginPage />} />
                 <Route path="/register" element={<RegisterPage />} />
                <Route path="/album" element={<AlbumPage />} />
                <Route path="/photographer" element={<PhotographerPage />} />
                 <Route path="/search" element={<SearchPage />} />
                 <Route path="/purchased" element={<PurchasedPhotosPage />} />
                <Route path="/cart" element={<CartPage />} />
                <Route path="/profile" element={<ProfilePage />} />
                <Route path="/" element={<LoginPage />} />
            </Routes>
        </Router>
    );
};

export default App;