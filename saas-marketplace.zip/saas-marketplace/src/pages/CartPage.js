import React, { useState } from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import photosData from "../data/photos.json";
import CartItem from "../components/CartItem";

const CartPage = () => {
    const [cartItems] = useState([photosData[0], photosData[1], photosData[2], photosData[3]]);
    const unitPrice = 25;
    const totalPrice = cartItems.length * unitPrice;

    return (
        <div>
            <Header>Carrinho de Compras</Header>
          <div className="cart-page">
          <div className="cart-items">
             {cartItems.map((item) => (
              <CartItem key={item.id} photo={item} />
            ))}
            </div>
            <div className="cart-summary">
                <p>Quantidade: {cartItems.length}</p>
                <p>Unit: R$ {unitPrice.toFixed(2)}</p>
                <p>Total: R$ {totalPrice.toFixed(2)}</p>
            </div>
              <div className="cart-buttons">
               <button className="add-more-photos-button">Adicionar mais fotos</button>
                <button className="finalize-purchase-button">Finalizar Compra</button>
            </div>
         </div>
            <Footer/>
        </div>
    );
};

export default CartPage;