import React, { useState } from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import Filter from "../components/Filter";
import photosData from '../data/photos.json';
import categoriesData from '../data/categories.json';

const SearchPage = () => {
  const [filteredPhotos, setFilteredPhotos] = useState(photosData);

  const handleFilter = (category) => {
      const filtered = photosData.filter(photo => photo.categories.includes(category));
      setFilteredPhotos(filtered);
  };

  return (
    <div>
      <Header>Buscas</Header>
        <Filter categories={categoriesData} onFilter={handleFilter}/>
      <div className="search-results">
        {filteredPhotos.map((photo) => (
          <div key={photo.id} className="photo-card">
            <img src={photo.url} alt={photo.title} />
               <div className="photo-details">
                 <p>{photo.description}</p>
                <p>Local: São Paulo</p>
                <p>Data: 10/10/2024</p>
              </div>
           </div>
        ))}
      </div>
        <Footer/>
    </div>
  );
};

export default SearchPage;