import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import photosData from '../data/photos.json';
import photographersData from '../data/photographers.json';

const PhotographerPage = () => {
  const photographerId = 1;
   const photographer = photographersData.find(photographer => photographer.id === photographerId);
    const photographerPhotos = photosData.filter(photo => photo.photographerId === photographerId);
  return (
    <div>
      <Header>Página do Fotógrafo</Header>
      <div className="photographer-page">
          <div className="photographer-details">
           <img src={photographer.photoURL} alt={photographer.name} className="photographer-image"/>
            <h2>{photographer.name}</h2>
            <p>{photographer.bio}</p>
          </div>
         <div className="photos-grid">
                {photographerPhotos.map((photo) => (
                  <div key={photo.id} className="photo-card">
                    <img src={photo.url} alt={photo.title} />
                      <div className="photo-details">
                       <p>{photo.description}</p>
                       <p>Local: São Paulo</p>
                       <p>Data: 10/10/2024</p>
                     </div>
                  </div>
                ))}
          </div>
      </div>
      <Footer/>
    </div>
  );
};

export default PhotographerPage;