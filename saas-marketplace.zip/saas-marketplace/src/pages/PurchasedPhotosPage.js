import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";
import PhotoCard from "../components/PhotoCard";
import photosData from '../data/photos.json';

const PurchasedPhotosPage = () => {
  return (
    <div>
      <Header>Suas Fotos Compradas</Header>
      <div className="photos-grid">
        {photosData.map((photo) => (
            <PhotoCard
                key={photo.id}
                photo={photo}
              />
         ))}
      </div>
        <Footer/>
    </div>
  );
};

export default PurchasedPhotosPage;