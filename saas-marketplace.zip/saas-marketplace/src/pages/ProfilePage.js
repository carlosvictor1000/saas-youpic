import React from 'react';
import Header from "../components/Header";
import Footer from "../components/Footer";

const ProfilePage = () => {
  return (
    <div>
      <Header>Perfil</Header>
      <div className="profile-page">
        <h2>Informações do Usuário</h2>
        <p>Nome: Usuário de Teste</p>
        <p>Email: teste@email.com</p>
        <h2>Suas Fotos Compradas (estáticas)</h2>
         <div className="photos-grid">
            </div>
      </div>
      <Footer/>
    </div>
  );
};

export default ProfilePage;