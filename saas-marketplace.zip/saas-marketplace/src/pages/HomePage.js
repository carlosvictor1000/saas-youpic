import React, { useState } from 'react';
import PhotoCard from '../components/PhotoCard';
import PhotoModal from '../components/PhotoModal';
import Header from "../components/Header";
import Footer from "../components/Footer";
import photosData from '../data/photos.json';

const HomePage = () => {
    const [selectedPhotos, setSelectedPhotos] = useState([]);
    const [selectedPhoto, setSelectedPhoto] = useState(null);

   const handleSelectPhoto = (photoId) => {
       if(selectedPhotos.includes(photoId)){
           setSelectedPhotos(selectedPhotos.filter(id => id !== photoId))
       }else {
           setSelectedPhotos([...selectedPhotos, photoId]);
       }
   };
    const handlePhotoClick = (photo) => {
        setSelectedPhoto(photo);
    };

    const handleCloseModal = () => {
        setSelectedPhoto(null);
    };

    const handleAddToCart = () => {
        console.log("adicionar ao carrinho");
        setSelectedPhoto(null);
    };

    return (
       <div>
            <Header>YouPic</Header>
             <div className="photos-grid">
            {photosData.map((photo) => (
                <PhotoCard
                    key={photo.id}
                    photo={photo}
                    onSelect={handleSelectPhoto}
                    selected={selectedPhotos.includes(photo.id)}
                onPhotoClick={() => handlePhotoClick(photo)}
                 />
            ))}
           </div>
             {selectedPhoto && (
             <PhotoModal
                 photo={selectedPhoto}
                 onClose={handleCloseModal}
                 onAddToCart={handleAddToCart}
             />
             )}
            <Footer/>
        </div>
    );
};

export default HomePage;