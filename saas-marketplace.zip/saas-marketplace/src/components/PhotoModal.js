import React from 'react';

const PhotoModal = ({ photo, onClose, onAddToCart }) => {
    return (
        <div className="modal">
            <div className="modal-content">
                <span className="close" onClick={onClose}>&times;</span>
                 <img src={photo.url} alt={photo.title} />
                <div className="photo-details">
                    <h2>{photo.title}</h2>
                    <p>{photo.description}</p>
                  <button className="add-to-cart" onClick={onAddToCart}>Adicionar ao carrinho</button>
                </div>
            </div>
        </div>
    );
};

export default PhotoModal;