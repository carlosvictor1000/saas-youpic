import React from 'react';

const Filter = ({ categories, onFilter }) => {
    return (
        <div className="filter">
           {categories.map((category) => (
               <button key={category.id} onClick={() => onFilter(category.name)}>
                   {category.name}
               </button>
           ))}
        </div>
    );
};

export default Filter;