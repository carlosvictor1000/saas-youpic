import React from 'react';

const PhotoCard = ({ photo, onSelect, selected }) => {

    const handleAddToCart = () => {
        onSelect(photo.id);
    };

    return (
        <div className={`photo-card ${selected ? "photo-card--selected" : ""}`} onClick={handleAddToCart}>
            <img src={photo.url} alt={photo.title} />
             {selected ? <span className="checkmark">✓</span> : <span className="plus">+</span>}
        </div>
    );
};

export default PhotoCard;