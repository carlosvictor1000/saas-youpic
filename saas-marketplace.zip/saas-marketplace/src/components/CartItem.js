import React from 'react';

const CartItem = ({ photo }) => {
    return (
        <div className="cart-item">
          <img src={photo.url} alt={photo.title}/>
          <span>{photo.title}</span>
        </div>
    );
};

export default CartItem;